use glam::Vec3;
use softforge::{mesh::Mesh, softbody::Params, voxelize::voxelize};

fn run(mut mesh: Mesh, name: &str) {
    mesh.normalize(2.0, 3.0);
    let (mut body, skin) = voxelize(&mesh, 10);
    println!("{name}: nodes={} springs={}", body.nodes.len(), body.springs.len());
    assert!(body.nodes.len() > 20);
    // skin reproduces the rest shape exactly
    let mut out = vec![Vec3::ZERO; mesh.positions.len()];
    skin.deform(&body, &mut out);
    for (a, b) in out.iter().zip(&mesh.positions) { assert!((*a - *b).length() < 1e-4); }
    let p = Params::default();
    for _ in 0..600 { body.step(1.0 / 60.0, &p, None); }
    let miny = body.nodes.iter().map(|n| n.pos.y).fold(f32::MAX, f32::min);
    let maxy = body.nodes.iter().map(|n| n.pos.y).fold(f32::MIN, f32::max);
    println!("  after 10s: y in [{miny:.3}, {maxy:.3}] strain={:.3}", body.max_strain());
    assert!(miny >= -1e-3 && maxy < 3.5 && body.nodes.iter().all(|n| n.pos.is_finite()));
    assert!(body.max_strain() < 0.3);
}

#[test] fn sphere() { run(Mesh::sphere(24, 16), "sphere"); }
#[test] fn cube() { run(Mesh::cube(), "cube"); }
