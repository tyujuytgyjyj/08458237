use softforge::{mesh::Mesh, softbody::Params, voxelize::voxelize};
#[test] fn jelly() {
    let mut m = Mesh::sphere(24,16); m.normalize(2.0,3.0);
    let (mut b,_) = voxelize(&m, 10);
    let p = Params{stiffness:0.3, substeps:4, iterations:4, ..Default::default()};
    let mut peak=0f32; let mut minh=9f32;
    for _ in 0..240 { b.step(1.0/60.0,&p,None); peak=peak.max(b.max_strain());
        let h=b.nodes.iter().map(|n|n.pos.y).fold(f32::MIN,f32::max); minh=minh.min(h);}
    println!("peak strain {peak:.3}, min height {minh:.3}");
    assert!(b.nodes.iter().all(|n|n.pos.is_finite()));
}
