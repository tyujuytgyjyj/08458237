# SoftForge — محرك أجسام رخوة (Rust + Direct3D 11)

## البناء والتشغيل (Windows)
1. ثبّت Rust من https://rustup.rs  (مع Visual Studio Build Tools - "Desktop development with C++")
2. افتح الطرفية داخل المجلد ثم:

    cargo run --release
    cargo run --release -- path\to\model.glb 14      (المسار، ثم دقة الشبكة الداخلية)

يمكنك أيضاً سحب وإفلات ملف .glb / .gltf / .obj على النافذة أثناء التشغيل.

## التحكم
- زر الماوس الأيسر: امسك الجسم واسحبه
- زر الماوس الأيمن + حركة: تدوير الكاميرا،  العجلة: تقريب/تبعيد
- R: إعادة الجسم | F: إظهار النوابض (ملونة بحسب الشد)
- 1: كرة | 2: مكعب
- السهم أعلى/أسفل: صلابة النوابض
- PageUp/PageDown: دقة الشبكة الداخلية (أعلى = أدق وأبطأ)

## كيف يعمل
mesh.rs      استيراد glTF/OBJ + تطبيع الحجم
voxelize.rs  يحوّل أي مجسم (حتى لو قشرة فارغة) إلى شبكة نقاط داخلية + نوابض، ويربط رؤوس المجسم الأصلي بالشبكة (skinning ثلاثي الخطية)
softbody.rs  محاكاة نقاط ونوابض (Position Based Dynamics) + أرض + جدران + سحب بالماوس
renderer.rs  رسام Direct3D 11 (windows-rs) ، shader.hlsl
app.rs       النافذة، الكاميرا، الإدخال، حلقة اللعبة
