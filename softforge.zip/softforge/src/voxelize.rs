use crate::mesh::Mesh;
use crate::softbody::{Node, SoftBody, Spring};
use glam::Vec3;
use std::collections::HashSet;

/// Embeds every render vertex inside one lattice cell (trilinear weights over its 8 corner nodes).
/// Physics runs on the lattice, rendering uses the original model deformed through it.
pub struct Skin {
    pub corners: Vec<[u32; 8]>,
    pub weights: Vec<[f32; 8]>,
}

impl Skin {
    pub fn deform(&self, body: &SoftBody, out: &mut [Vec3]) {
        for (i, o) in out.iter_mut().enumerate() {
            let c = &self.corners[i];
            let w = &self.weights[i];
            let mut p = Vec3::ZERO;
            for k in 0..8 { p += body.nodes[c[k] as usize].pos * w[k]; }
            *o = p;
        }
    }
}

/// Convert any triangle mesh (even a hollow shell) into a soft body.
/// `res` = number of lattice cells along the longest axis.
pub fn voxelize(mesh: &Mesh, res: usize) -> (SoftBody, Skin) {
    let (mn, mx) = mesh.bounds();
    let ext = mx - mn;
    let cell = (ext.max_element() / res.max(2) as f32).max(1e-5);
    let dims = [
        ((ext.x / cell).ceil() as usize).max(1),
        ((ext.y / cell).ceil() as usize).max(1),
        ((ext.z / cell).ceil() as usize).max(1),
    ];
    let cidx = |x: usize, y: usize, z: usize| (z * dims[1] + y) * dims[0] + x;
    let mut filled = vec![false; dims[0] * dims[1] * dims[2]];
    let cell_of = |p: Vec3| -> [usize; 3] {
        let l = (p - mn) / cell;
        [
            (l.x.floor().max(0.0) as usize).min(dims[0] - 1),
            (l.y.floor().max(0.0) as usize).min(dims[1] - 1),
            (l.z.floor().max(0.0) as usize).min(dims[2] - 1),
        ]
    };

    // 1) surface: mark every cell touched by a triangle (dense sampling)
    for t in mesh.indices.chunks_exact(3) {
        let (a, b, c) = (mesh.positions[t[0] as usize], mesh.positions[t[1] as usize], mesh.positions[t[2] as usize]);
        let longest = (b - a).length().max((c - b).length()).max((a - c).length());
        let n = ((longest / (cell * 0.5)).ceil() as usize).clamp(1, 512);
        for i in 0..=n {
            for j in 0..=(n - i) {
                let (u, v) = (i as f32 / n as f32, j as f32 / n as f32);
                let p = a + (b - a) * u + (c - a) * v;
                let [x, y, z] = cell_of(p);
                filled[cidx(x, y, z)] = true;
            }
        }
    }

    // 2) interior: cast one ray per (y,z) column along +X, fill between crossing pairs
    let mut cols: Vec<Vec<f32>> = vec![Vec::new(); dims[1] * dims[2]];
    let jit = cell * 0.0137; // avoid rays hitting shared edges exactly
    for t in mesh.indices.chunks_exact(3) {
        let (a, b, c) = (mesh.positions[t[0] as usize], mesh.positions[t[1] as usize], mesh.positions[t[2] as usize]);
        let (ymin, ymax) = (a.y.min(b.y).min(c.y), a.y.max(b.y).max(c.y));
        let (zmin, zmax) = (a.z.min(b.z).min(c.z), a.z.max(b.z).max(c.z));
        let iy0 = (((ymin - mn.y) / cell - 0.5).floor().max(0.0)) as usize;
        let iy1 = ((((ymax - mn.y) / cell - 0.5).ceil().max(0.0)) as usize).min(dims[1] - 1);
        let iz0 = (((zmin - mn.z) / cell - 0.5).floor().max(0.0)) as usize;
        let iz1 = ((((zmax - mn.z) / cell - 0.5).ceil().max(0.0)) as usize).min(dims[2] - 1);
        let den = (b.y - a.y) * (c.z - a.z) - (c.y - a.y) * (b.z - a.z);
        if den.abs() < 1e-12 { continue; }
        for iz in iz0..=iz1 {
            for iy in iy0..=iy1 {
                let py = mn.y + (iy as f32 + 0.5) * cell + jit;
                let pz = mn.z + (iz as f32 + 0.5) * cell + jit * 1.3;
                let u = ((py - a.y) * (c.z - a.z) - (c.y - a.y) * (pz - a.z)) / den;
                let v = ((b.y - a.y) * (pz - a.z) - (py - a.y) * (b.z - a.z)) / den;
                if u >= 0.0 && v >= 0.0 && u + v <= 1.0 {
                    cols[iz * dims[1] + iy].push(a.x + (b.x - a.x) * u + (c.x - a.x) * v);
                }
            }
        }
    }
    for iz in 0..dims[2] {
        for iy in 0..dims[1] {
            let xs = &mut cols[iz * dims[1] + iy];
            if xs.len() < 2 || xs.len() % 2 != 0 { continue; } // open/non-manifold column: keep surface only
            xs.sort_by(|a, b| a.partial_cmp(b).unwrap());
            for pair in xs.chunks_exact(2) {
                for ix in 0..dims[0] {
                    let cx = mn.x + (ix as f32 + 0.5) * cell;
                    if cx >= pair[0] && cx <= pair[1] { filled[cidx(ix, iy, iz)] = true; }
                }
            }
        }
    }

    // 3) nodes at corners of filled cells
    let nd = [dims[0] + 1, dims[1] + 1, dims[2] + 1];
    let nidx = |x: usize, y: usize, z: usize| (z * nd[1] + y) * nd[0] + x;
    let mut node_id = vec![u32::MAX; nd[0] * nd[1] * nd[2]];
    let mut nodes: Vec<Node> = Vec::new();
    let mut springs: Vec<Spring> = Vec::new();
    let mut seen: HashSet<(u32, u32)> = HashSet::new();

    for z in 0..dims[2] {
        for y in 0..dims[1] {
            for x in 0..dims[0] {
                if !filled[cidx(x, y, z)] { continue; }
                let mut ids = [0u32; 8];
                for k in 0..8usize {
                    let (cx, cy, cz) = (x + (k & 1), y + ((k >> 1) & 1), z + ((k >> 2) & 1));
                    let slot = &mut node_id[nidx(cx, cy, cz)];
                    if *slot == u32::MAX {
                        *slot = nodes.len() as u32;
                        let p = mn + Vec3::new(cx as f32, cy as f32, cz as f32) * cell;
                        nodes.push(Node { pos: p, prev: p, inv_mass: 1.0 });
                    }
                    ids[k] = *slot;
                }
                // edges (differ by 1 bit), face diagonals (2 bits), body diagonals (3 bits)
                for i in 0..8usize {
                    for j in (i + 1)..8usize {
                        let (a, b) = (ids[i].min(ids[j]), ids[i].max(ids[j]));
                        if seen.insert((a, b)) {
                            let rest = (nodes[a as usize].pos - nodes[b as usize].pos).length();
                            springs.push(Spring { a, b, rest });
                        }
                    }
                }
            }
        }
    }

    // 4) skin
    let mut corners = Vec::with_capacity(mesh.positions.len());
    let mut weights = Vec::with_capacity(mesh.positions.len());
    for p in &mesh.positions {
        let [x, y, z] = cell_of(*p);
        let l = (*p - mn) / cell - Vec3::new(x as f32, y as f32, z as f32);
        let f = l.clamp(Vec3::ZERO, Vec3::ONE);
        let mut c = [0u32; 8];
        let mut w = [0f32; 8];
        for k in 0..8usize {
            let (bx, by, bz) = (k & 1, (k >> 1) & 1, (k >> 2) & 1);
            c[k] = node_id[nidx(x + bx, y + by, z + bz)];
            debug_assert!(c[k] != u32::MAX, "vertex fell outside filled cells");
            w[k] = (if bx == 1 { f.x } else { 1.0 - f.x })
                 * (if by == 1 { f.y } else { 1.0 - f.y })
                 * (if bz == 1 { f.z } else { 1.0 - f.z });
        }
        corners.push(c);
        weights.push(w);
    }
    (SoftBody { nodes, springs }, Skin { corners, weights })
}
