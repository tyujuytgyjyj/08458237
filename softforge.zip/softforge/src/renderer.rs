//! Minimal Direct3D 11 renderer (windows-rs). One shader, dynamic vertex/index buffers.
use std::ffi::c_void;
use windows::core::PCSTR;
use windows::Win32::Foundation::{HMODULE, HWND};
use windows::Win32::Graphics::Direct3D::Fxc::*;
use windows::Win32::Graphics::Direct3D::*;
use windows::Win32::Graphics::Direct3D11::*;
use windows::Win32::Graphics::Dxgi::Common::*;
use windows::Win32::Graphics::Dxgi::*;

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
pub struct Vertex {
    pub pos: [f32; 3],
    pub nrm: [f32; 3],
    pub col: [f32; 3],
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Constants {
    vp: [f32; 16],
    light: [f32; 4],
}

pub struct Renderer {
    device: ID3D11Device,
    ctx: ID3D11DeviceContext,
    swap: IDXGISwapChain,
    rtv: Option<ID3D11RenderTargetView>,
    dsv: Option<ID3D11DepthStencilView>,
    vs: ID3D11VertexShader,
    ps: ID3D11PixelShader,
    layout: ID3D11InputLayout,
    cb: ID3D11Buffer,
    raster: ID3D11RasterizerState,
    depth_state: ID3D11DepthStencilState,
    vb: ID3D11Buffer,
    vb_cap: usize,
    ib: ID3D11Buffer,
    ib_cap: usize,
    size: (u32, u32),
}

fn dyn_buffer(device: &ID3D11Device, bytes: usize, bind: D3D11_BIND_FLAG) -> windows::core::Result<ID3D11Buffer> {
    let desc = D3D11_BUFFER_DESC {
        ByteWidth: bytes as u32,
        Usage: D3D11_USAGE_DYNAMIC,
        BindFlags: bind.0 as u32,
        CPUAccessFlags: D3D11_CPU_ACCESS_WRITE.0 as u32,
        MiscFlags: 0,
        StructureByteStride: 0,
    };
    let mut buf = None;
    unsafe { device.CreateBuffer(&desc, None, Some(&mut buf))? };
    Ok(buf.unwrap())
}

fn compile(src: &str, entry: &[u8], target: &[u8]) -> Result<ID3DBlob, String> {
    let mut blob: Option<ID3DBlob> = None;
    let mut err: Option<ID3DBlob> = None;
    let r = unsafe {
        D3DCompile(
            src.as_ptr() as *const c_void,
            src.len(),
            PCSTR::null(),
            None,
            None,
            PCSTR(entry.as_ptr()),
            PCSTR(target.as_ptr()),
            D3DCOMPILE_ENABLE_STRICTNESS,
            0,
            &mut blob,
            Some(&mut err),
        )
    };
    if r.is_err() {
        let msg = err
            .map(|e| unsafe {
                let s = std::slice::from_raw_parts(e.GetBufferPointer() as *const u8, e.GetBufferSize());
                String::from_utf8_lossy(s).to_string()
            })
            .unwrap_or_else(|| format!("{r:?}"));
        return Err(msg);
    }
    Ok(blob.unwrap())
}

fn blob_bytes(b: &ID3DBlob) -> &[u8] {
    unsafe { std::slice::from_raw_parts(b.GetBufferPointer() as *const u8, b.GetBufferSize()) }
}

impl Renderer {
    pub fn new(hwnd: HWND, w: u32, h: u32) -> Result<Self, String> {
        let (w, h) = (w.max(1), h.max(1));
        let desc = DXGI_SWAP_CHAIN_DESC {
            BufferDesc: DXGI_MODE_DESC {
                Width: w,
                Height: h,
                Format: DXGI_FORMAT_R8G8B8A8_UNORM,
                ..Default::default()
            },
            SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
            BufferUsage: DXGI_USAGE_RENDER_TARGET_OUTPUT,
            BufferCount: 1,
            OutputWindow: hwnd,
            Windowed: true.into(),
            SwapEffect: DXGI_SWAP_EFFECT_DISCARD,
            Flags: 0,
        };
        let mut device = None;
        let mut ctx = None;
        let mut swap = None;
        unsafe {
            D3D11CreateDeviceAndSwapChain(
                None,
                D3D_DRIVER_TYPE_HARDWARE,
                HMODULE::default(),
                D3D11_CREATE_DEVICE_FLAG(0),
                Some(&[D3D_FEATURE_LEVEL_11_0]),
                D3D11_SDK_VERSION,
                Some(&desc),
                Some(&mut swap),
                Some(&mut device),
                None,
                Some(&mut ctx),
            )
            .map_err(|e| format!("D3D11CreateDeviceAndSwapChain: {e}"))?;
        }
        let (device, ctx, swap) = (device.unwrap(), ctx.unwrap(), swap.unwrap());

        let src = include_str!("shader.hlsl");
        let vs_blob = compile(src, b"VSMain\0", b"vs_5_0\0")?;
        let ps_blob = compile(src, b"PSMain\0", b"ps_5_0\0")?;
        let mut vs = None;
        let mut ps = None;
        let mut layout = None;
        let sem = |name: &'static [u8], off: u32| D3D11_INPUT_ELEMENT_DESC {
            SemanticName: PCSTR(name.as_ptr()),
            SemanticIndex: 0,
            Format: DXGI_FORMAT_R32G32B32_FLOAT,
            InputSlot: 0,
            AlignedByteOffset: off,
            InputSlotClass: D3D11_INPUT_PER_VERTEX_DATA,
            InstanceDataStepRate: 0,
        };
        let elems = [sem(b"POSITION\0", 0), sem(b"NORMAL\0", 12), sem(b"COLOR\0", 24)];
        unsafe {
            device.CreateVertexShader(blob_bytes(&vs_blob), None, Some(&mut vs)).map_err(|e| e.to_string())?;
            device.CreatePixelShader(blob_bytes(&ps_blob), None, Some(&mut ps)).map_err(|e| e.to_string())?;
            device
                .CreateInputLayout(&elems, blob_bytes(&vs_blob), Some(&mut layout))
                .map_err(|e| e.to_string())?;
        }

        let cb = dyn_buffer(&device, std::mem::size_of::<Constants>(), D3D11_BIND_CONSTANT_BUFFER)
            .map_err(|e| e.to_string())?;

        let mut raster = None;
        let rd = D3D11_RASTERIZER_DESC {
            FillMode: D3D11_FILL_SOLID,
            CullMode: D3D11_CULL_NONE,
            DepthClipEnable: true.into(),
            ..Default::default()
        };
        let mut dss = None;
        let dd = D3D11_DEPTH_STENCIL_DESC {
            DepthEnable: true.into(),
            DepthWriteMask: D3D11_DEPTH_WRITE_MASK_ALL,
            DepthFunc: D3D11_COMPARISON_LESS_EQUAL,
            StencilEnable: false.into(),
            ..Default::default()
        };
        unsafe {
            device.CreateRasterizerState(&rd, Some(&mut raster)).map_err(|e| e.to_string())?;
            device.CreateDepthStencilState(&dd, Some(&mut dss)).map_err(|e| e.to_string())?;
        }

        let vb_cap = 1 << 20;
        let ib_cap = 1 << 20;
        let vb = dyn_buffer(&device, vb_cap, D3D11_BIND_VERTEX_BUFFER).map_err(|e| e.to_string())?;
        let ib = dyn_buffer(&device, ib_cap, D3D11_BIND_INDEX_BUFFER).map_err(|e| e.to_string())?;

        let mut r = Renderer {
            device,
            ctx,
            swap,
            rtv: None,
            dsv: None,
            vs: vs.unwrap(),
            ps: ps.unwrap(),
            layout: layout.unwrap(),
            cb,
            raster: raster.unwrap(),
            depth_state: dss.unwrap(),
            vb,
            vb_cap,
            ib,
            ib_cap,
            size: (w, h),
        };
        r.create_targets().map_err(|e| e.to_string())?;
        Ok(r)
    }

    fn create_targets(&mut self) -> windows::core::Result<()> {
        let (w, h) = self.size;
        unsafe {
            let back: ID3D11Texture2D = self.swap.GetBuffer(0)?;
            let mut rtv = None;
            self.device.CreateRenderTargetView(&back, None, Some(&mut rtv))?;
            self.rtv = rtv;

            let td = D3D11_TEXTURE2D_DESC {
                Width: w,
                Height: h,
                MipLevels: 1,
                ArraySize: 1,
                Format: DXGI_FORMAT_D32_FLOAT,
                SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                Usage: D3D11_USAGE_DEFAULT,
                BindFlags: D3D11_BIND_DEPTH_STENCIL.0 as u32,
                CPUAccessFlags: 0,
                MiscFlags: 0,
            };
            let mut tex = None;
            self.device.CreateTexture2D(&td, None, Some(&mut tex))?;
            let tex = tex.unwrap();
            let mut dsv = None;
            self.device.CreateDepthStencilView(&tex, None, Some(&mut dsv))?;
            self.dsv = dsv;
        }
        Ok(())
    }

    pub fn resize(&mut self, w: u32, h: u32) {
        if w == 0 || h == 0 || (w, h) == self.size {
            return;
        }
        self.size = (w, h);
        unsafe {
            self.ctx.OMSetRenderTargets(None, None);
            self.rtv = None;
            self.dsv = None;
            if self.swap.ResizeBuffers(0, w, h, DXGI_FORMAT_UNKNOWN, DXGI_SWAP_CHAIN_FLAG(0)).is_ok() {
                let _ = self.create_targets();
            }
        }
    }

    pub fn aspect(&self) -> f32 {
        self.size.0 as f32 / self.size.1 as f32
    }

    pub fn begin(&mut self, view_proj: [f32; 16], light: [f32; 4], clear: [f32; 4]) {
        let c = Constants { vp: view_proj, light };
        unsafe {
            self.upload(&self.cb.clone(), bytemuck::bytes_of(&c));
            let rtv = self.rtv.clone().unwrap();
            let dsv = self.dsv.clone().unwrap();
            self.ctx.OMSetRenderTargets(Some(&[Some(rtv.clone())]), &dsv);
            self.ctx.ClearRenderTargetView(&rtv, &clear);
            self.ctx.ClearDepthStencilView(&dsv, D3D11_CLEAR_DEPTH.0 as u32, 1.0, 0);
            let vp = D3D11_VIEWPORT {
                TopLeftX: 0.0,
                TopLeftY: 0.0,
                Width: self.size.0 as f32,
                Height: self.size.1 as f32,
                MinDepth: 0.0,
                MaxDepth: 1.0,
            };
            self.ctx.RSSetViewports(Some(&[vp]));
            self.ctx.RSSetState(&self.raster);
            self.ctx.OMSetDepthStencilState(&self.depth_state, 0);
            self.ctx.IASetInputLayout(&self.layout);
            self.ctx.VSSetShader(&self.vs, None);
            self.ctx.PSSetShader(&self.ps, None);
            self.ctx.VSSetConstantBuffers(0, Some(&[Some(self.cb.clone())]));
        }
    }

    unsafe fn upload(&self, buf: &ID3D11Buffer, bytes: &[u8]) {
        let mut m = D3D11_MAPPED_SUBRESOURCE::default();
        if self.ctx.Map(buf, 0, D3D11_MAP_WRITE_DISCARD, 0, Some(&mut m)).is_ok() {
            std::ptr::copy_nonoverlapping(bytes.as_ptr(), m.pData as *mut u8, bytes.len());
            self.ctx.Unmap(buf, 0);
        }
    }

    fn ensure_capacity(&mut self, vbytes: usize, ibytes: usize) {
        if vbytes > self.vb_cap {
            self.vb_cap = vbytes.next_power_of_two();
            self.vb = dyn_buffer(&self.device, self.vb_cap, D3D11_BIND_VERTEX_BUFFER).expect("vb");
        }
        if ibytes > self.ib_cap {
            self.ib_cap = ibytes.next_power_of_two();
            self.ib = dyn_buffer(&self.device, self.ib_cap, D3D11_BIND_INDEX_BUFFER).expect("ib");
        }
    }

    /// Indexed triangle list.
    pub fn draw_triangles(&mut self, verts: &[Vertex], indices: &[u32]) {
        if verts.is_empty() || indices.is_empty() {
            return;
        }
        let vbytes: &[u8] = bytemuck::cast_slice(verts);
        let ibytes: &[u8] = bytemuck::cast_slice(indices);
        self.ensure_capacity(vbytes.len(), ibytes.len());
        unsafe {
            self.upload(&self.vb, vbytes);
            self.upload(&self.ib, ibytes);
            let stride = std::mem::size_of::<Vertex>() as u32;
            let offset = 0u32;
            let vb = Some(self.vb.clone());
            self.ctx.IASetVertexBuffers(0, 1, Some(&vb), Some(&stride), Some(&offset));
            self.ctx.IASetIndexBuffer(&self.ib, DXGI_FORMAT_R32_UINT, 0);
            self.ctx.IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            self.ctx.DrawIndexed(indices.len() as u32, 0, 0);
        }
    }

    /// Line list (every 2 vertices = one line). Use zero normals for unlit colour.
    pub fn draw_lines(&mut self, verts: &[Vertex]) {
        if verts.len() < 2 {
            return;
        }
        let vbytes: &[u8] = bytemuck::cast_slice(verts);
        self.ensure_capacity(vbytes.len(), 0);
        unsafe {
            self.upload(&self.vb, vbytes);
            let stride = std::mem::size_of::<Vertex>() as u32;
            let offset = 0u32;
            let vb = Some(self.vb.clone());
            self.ctx.IASetVertexBuffers(0, 1, Some(&vb), Some(&stride), Some(&offset));
            self.ctx.IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINELIST);
            self.ctx.Draw(verts.len() as u32, 0);
        }
    }

    pub fn end(&mut self) {
        unsafe {
            let _ = self.swap.Present(1, DXGI_PRESENT(0));
        }
    }
}
