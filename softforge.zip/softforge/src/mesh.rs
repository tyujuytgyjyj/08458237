use glam::{Mat4, Vec3};
use std::path::Path;

/// A simple triangle mesh used for rendering (the "pretty" model).
#[derive(Clone, Default)]
pub struct Mesh {
    pub positions: Vec<Vec3>,
    pub colors: Vec<Vec3>,
    pub indices: Vec<u32>,
}

impl Mesh {
    pub fn bounds(&self) -> (Vec3, Vec3) {
        let mut mn = Vec3::splat(f32::MAX);
        let mut mx = Vec3::splat(f32::MIN);
        for p in &self.positions {
            mn = mn.min(*p);
            mx = mx.max(*p);
        }
        (mn, mx)
    }

    /// Scale so the largest dimension equals `size`, center on XZ, put the bottom at y = 0,
    /// then lift by `lift`.
    pub fn normalize(&mut self, size: f32, lift: f32) {
        let (mn, mx) = self.bounds();
        let ext = (mx - mn).max_element().max(1e-6);
        let s = size / ext;
        let center = Vec3::new((mn.x + mx.x) * 0.5, mn.y, (mn.z + mx.z) * 0.5);
        for p in &mut self.positions {
            *p = (*p - center) * s + Vec3::new(0.0, lift, 0.0);
        }
    }

    pub fn normals(positions: &[Vec3], indices: &[u32]) -> Vec<Vec3> {
        let mut n = vec![Vec3::ZERO; positions.len()];
        for t in indices.chunks_exact(3) {
            let (a, b, c) = (t[0] as usize, t[1] as usize, t[2] as usize);
            let fn_ = (positions[b] - positions[a]).cross(positions[c] - positions[a]);
            n[a] += fn_;
            n[b] += fn_;
            n[c] += fn_;
        }
        for v in &mut n {
            *v = v.normalize_or_zero();
        }
        n
    }

    pub fn sphere(segments: u32, rings: u32) -> Mesh {
        let mut m = Mesh::default();
        for r in 0..=rings {
            let v = r as f32 / rings as f32;
            let phi = v * std::f32::consts::PI;
            for s in 0..=segments {
                let u = s as f32 / segments as f32;
                let th = u * std::f32::consts::TAU;
                m.positions.push(Vec3::new(phi.sin() * th.cos(), phi.cos(), phi.sin() * th.sin()) * 0.5);
                m.colors.push(Vec3::new(0.95, 0.45, 0.25));
            }
        }
        let w = segments + 1;
        for r in 0..rings {
            for s in 0..segments {
                let a = r * w + s;
                let b = a + w;
                m.indices.extend_from_slice(&[a, a + 1, b, a + 1, b + 1, b]);
            }
        }
        m
    }

    pub fn cube() -> Mesh {
        let mut m = Mesh::default();
        let c = Vec3::new(0.3, 0.6, 0.95);
        for i in 0..8u32 {
            m.positions.push(Vec3::new(
                if i & 1 == 0 { -0.5 } else { 0.5 },
                if i & 2 == 0 { -0.5 } else { 0.5 },
                if i & 4 == 0 { -0.5 } else { 0.5 },
            ));
            m.colors.push(c);
        }
        let q = |a: u32, b: u32, c: u32, d: u32| [a, b, c, a, c, d];
        for f in [
            q(0, 2, 3, 1), q(4, 5, 7, 6), q(0, 1, 5, 4),
            q(2, 6, 7, 3), q(0, 4, 6, 2), q(1, 3, 7, 5),
        ] {
            m.indices.extend_from_slice(&f);
        }
        m
    }

    pub fn load(path: &Path) -> Result<Mesh, String> {
        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("").to_lowercase();
        match ext.as_str() {
            #[cfg(feature = "gltf")]
            "glb" | "gltf" => load_gltf(path),
            "obj" => load_obj(path),
            _ => Err(format!("unsupported format: .{ext} (use .glb .gltf .obj)")),
        }
    }
}

fn load_obj(path: &Path) -> Result<Mesh, String> {
    let opts = tobj::LoadOptions { triangulate: true, single_index: true, ..Default::default() };
    let (models, _) = tobj::load_obj(path, &opts).map_err(|e| e.to_string())?;
    let mut m = Mesh::default();
    for model in models {
        let base = m.positions.len() as u32;
        for p in model.mesh.positions.chunks_exact(3) {
            m.positions.push(Vec3::new(p[0], p[1], p[2]));
            m.colors.push(Vec3::new(0.8, 0.8, 0.85));
        }
        m.indices.extend(model.mesh.indices.iter().map(|i| i + base));
    }
    if m.indices.is_empty() { return Err("OBJ has no triangles".into()); }
    Ok(m)
}

#[cfg(feature = "gltf")]
fn load_gltf(path: &Path) -> Result<Mesh, String> {
    let (doc, buffers, _images) = gltf::import(path).map_err(|e| e.to_string())?;
    let mut m = Mesh::default();
    let scene = doc.default_scene().or_else(|| doc.scenes().next()).ok_or("no scene")?;
    fn visit(node: gltf::Node, parent: Mat4, buffers: &[gltf::buffer::Data], m: &mut Mesh) {
        let world = parent * Mat4::from_cols_array_2d(&node.transform().matrix());
        if let Some(mesh) = node.mesh() {
            for prim in mesh.primitives() {
                if prim.mode() != gltf::mesh::Mode::Triangles { continue; }
                let reader = prim.reader(|b| Some(&buffers[b.index()]));
                let Some(pos) = reader.read_positions() else { continue };
                let base = m.positions.len() as u32;
                let col = prim.material().pbr_metallic_roughness().base_color_factor();
                let col = Vec3::new(col[0], col[1], col[2]);
                for p in pos {
                    m.positions.push(world.transform_point3(Vec3::from(p)));
                    m.colors.push(col);
                }
                let n = m.positions.len() as u32 - base;
                if let Some(idx) = reader.read_indices() {
                    m.indices.extend(idx.into_u32().map(|i| i + base));
                } else {
                    m.indices.extend(base..base + n);
                }
            }
        }
        for c in node.children() { visit(c, world, buffers, m); }
    }
    for n in scene.nodes() { visit(n, Mat4::IDENTITY, &buffers, &mut m); }
    if m.indices.is_empty() { return Err("glTF has no triangles".into()); }
    Ok(m)
}
