use crate::renderer::{Renderer, Vertex};
use glam::{Mat4, Vec3};
use raw_window_handle::{HasWindowHandle, RawWindowHandle};
use softforge::mesh::Mesh;
use softforge::softbody::{Params, SoftBody};
use softforge::voxelize::{voxelize, Skin};
use std::path::{Path, PathBuf};
use std::time::Instant;
use winit::dpi::PhysicalSize;
use winit::event::{ElementState, Event, MouseButton, MouseScrollDelta, WindowEvent};
use winit::event_loop::{ControlFlow, EventLoop};
use winit::keyboard::{KeyCode, PhysicalKey};
use winit::window::WindowBuilder;
use windows::Win32::Foundation::HWND;

struct Scene {
    mesh: Mesh, // normalized rest model
    body: SoftBody,
    skin: Skin,
    rest: Vec<Vec3>,
    deformed: Vec<Vec3>,
    verts: Vec<Vertex>,
    name: String,
}

impl Scene {
    fn build(mut mesh: Mesh, res: usize, name: String) -> Scene {
        // First build normalizes; rebuilds (res change) pass an already-normalized mesh, which is idempotent enough.
        mesh.normalize(2.0, 3.0);
        Self::from_normalized(mesh, res, name)
    }

    fn from_normalized(mesh: Mesh, res: usize, name: String) -> Scene {
        let (body, skin) = voxelize(&mesh, res);
        let rest = body.nodes.iter().map(|n| n.pos).collect();
        let n = mesh.positions.len();
        let mut s = Scene {
            verts: vec![Vertex { pos: [0.0; 3], nrm: [0.0; 3], col: [0.0; 3] }; n],
            deformed: vec![Vec3::ZERO; n],
            mesh,
            body,
            skin,
            rest,
            name,
        };
        s.refresh();
        s
    }

    fn reset(&mut self) {
        for (n, r) in self.body.nodes.iter_mut().zip(&self.rest) {
            n.pos = *r;
            n.prev = *r;
        }
        self.refresh();
    }

    fn refresh(&mut self) {
        self.skin.deform(&self.body, &mut self.deformed);
        let normals = Mesh::normals(&self.deformed, &self.mesh.indices);
        for i in 0..self.verts.len() {
            self.verts[i] = Vertex {
                pos: self.deformed[i].to_array(),
                nrm: normals[i].to_array(),
                col: self.mesh.colors[i].to_array(),
            };
        }
    }
}

struct Camera {
    yaw: f32,
    pitch: f32,
    dist: f32,
    target: Vec3,
}

impl Camera {
    fn eye(&self) -> Vec3 {
        self.target
            + self.dist
                * Vec3::new(self.pitch.cos() * self.yaw.sin(), self.pitch.sin(), self.pitch.cos() * self.yaw.cos())
    }
    fn view_proj(&self, aspect: f32) -> Mat4 {
        let view = Mat4::look_at_rh(self.eye(), self.target, Vec3::Y);
        let proj = Mat4::perspective_rh(60f32.to_radians(), aspect, 0.1, 300.0);
        proj * view
    }
}

fn ground_mesh(wall: f32) -> (Vec<Vertex>, Vec<u32>, Vec<Vertex>) {
    let y = -0.003;
    let c = [0.16, 0.18, 0.21];
    let q = |x: f32, z: f32| Vertex { pos: [x, y, z], nrm: [0.0, 1.0, 0.0], col: c };
    let verts = vec![q(-wall, -wall), q(wall, -wall), q(wall, wall), q(-wall, wall)];
    // zero-normal => unlit would be flat; keep a normal so the floor is lit
    let idx = vec![0, 1, 2, 0, 2, 3];
    let mut lines = Vec::new();
    let mut add = |a: [f32; 3], b: [f32; 3], col: [f32; 3]| {
        lines.push(Vertex { pos: a, nrm: [0.0; 3], col });
        lines.push(Vertex { pos: b, nrm: [0.0; 3], col });
    };
    let n = wall as i32;
    for i in -n..=n {
        let f = i as f32;
        let col = if i == -n || i == n { [0.55, 0.6, 0.65] } else { [0.26, 0.29, 0.33] };
        add([f, 0.0, -wall], [f, 0.0, wall], col);
        add([-wall, 0.0, f], [wall, 0.0, f], col);
    }
    (verts, idx, lines)
}

fn load_from(path: &Path) -> Result<Mesh, String> {
    Mesh::load(path)
}

pub fn run() {
    let args: Vec<String> = std::env::args().collect();
    let mut res: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(12).clamp(4, 40);

    let initial = match args.get(1) {
        Some(p) => match load_from(Path::new(p)) {
            Ok(m) => (m, p.clone()),
            Err(e) => {
                eprintln!("Failed to load {p}: {e}. Using built-in sphere.");
                (Mesh::sphere(24, 16), "sphere".into())
            }
        },
        None => (Mesh::sphere(24, 16), "sphere".into()),
    };
    let mut scene = Scene::build(initial.0, res, initial.1);

    let event_loop = EventLoop::new().expect("event loop");
    event_loop.set_control_flow(ControlFlow::Poll);
    let window = WindowBuilder::new()
        .with_title("SoftForge")
        .with_inner_size(PhysicalSize::new(1280, 720))
        .build(&event_loop)
        .expect("window");

    let hwnd = match window.window_handle().expect("handle").as_raw() {
        RawWindowHandle::Win32(h) => HWND(h.hwnd.get() as *mut _),
        _ => panic!("not a Win32 window"),
    };
    let size = window.inner_size();
    let mut renderer = Renderer::new(hwnd, size.width, size.height).unwrap_or_else(|e| {
        eprintln!("Direct3D 11 init failed:\n{e}");
        std::process::exit(1);
    });

    let params_default = Params::default();
    let mut params = params_default;
    let (ground_v, ground_i, grid_lines) = ground_mesh(params.wall);
    let mut cam = Camera { yaw: 0.6, pitch: 0.35, dist: 9.0, target: Vec3::new(0.0, 1.2, 0.0) };
    let mut show_springs = false;
    let mut mouse = (0.0f64, 0.0f64);
    let mut left = false;
    let mut right = false;
    let mut grab: Option<(usize, f32)> = None;
    let mut last = Instant::now();
    let mut acc = 0.0f32;
    let mut frames = 0u32;
    let light = Vec3::new(0.4, 1.0, 0.3).normalize();

    let ray = |mouse: (f64, f64), cam: &Camera, w: &winit::window::Window| -> (Vec3, Vec3) {
        let s = w.inner_size();
        let nx = (2.0 * mouse.0 as f32 / s.width.max(1) as f32) - 1.0;
        let ny = 1.0 - (2.0 * mouse.1 as f32 / s.height.max(1) as f32);
        let inv = cam.view_proj(s.width.max(1) as f32 / s.height.max(1) as f32).inverse();
        let near = inv.project_point3(Vec3::new(nx, ny, 0.0));
        let far = inv.project_point3(Vec3::new(nx, ny, 1.0));
        (near, (far - near).normalize())
    };

    event_loop
        .run(move |event, elwt| match event {
            Event::AboutToWait => window.request_redraw(),
            Event::WindowEvent { event, .. } => match event {
                WindowEvent::CloseRequested => elwt.exit(),
                WindowEvent::Resized(s) => renderer.resize(s.width, s.height),
                WindowEvent::CursorMoved { position, .. } => {
                    if right {
                        cam.yaw -= (position.x - mouse.0) as f32 * 0.005;
                        cam.pitch = (cam.pitch + (position.y - mouse.1) as f32 * 0.005).clamp(-1.4, 1.5);
                    }
                    mouse = (position.x, position.y);
                }
                WindowEvent::MouseWheel { delta, .. } => {
                    let y = match delta {
                        MouseScrollDelta::LineDelta(_, y) => y,
                        MouseScrollDelta::PixelDelta(p) => p.y as f32 / 50.0,
                    };
                    cam.dist = (cam.dist * 0.9f32.powf(y)).clamp(1.5, 60.0);
                }
                WindowEvent::MouseInput { state, button, .. } => {
                    let down = state == ElementState::Pressed;
                    match button {
                        MouseButton::Right => right = down,
                        MouseButton::Left => {
                            left = down;
                            if down {
                                let (o, d) = ray(mouse, &cam, &window);
                                grab = scene.body.pick(o, d).filter(|b| b.2 < 0.6).map(|b| (b.0, b.1));
                            } else {
                                grab = None;
                            }
                        }
                        _ => {}
                    }
                }
                WindowEvent::DroppedFile(path) => {
                    let p: PathBuf = path;
                    match Mesh::load(&p) {
                        Ok(m) => {
                            scene = Scene::build(m, res, p.display().to_string());
                            grab = None;
                        }
                        Err(e) => window.set_title(&format!("SoftForge | load failed: {e}")),
                    }
                }
                WindowEvent::KeyboardInput { event, .. } if event.state == ElementState::Pressed => {
                    if let PhysicalKey::Code(k) = event.physical_key {
                        match k {
                            KeyCode::Escape => elwt.exit(),
                            KeyCode::KeyR => scene.reset(),
                            KeyCode::KeyF => show_springs = !show_springs,
                            KeyCode::Digit1 => {
                                scene = Scene::build(Mesh::sphere(24, 16), res, "sphere".into());
                                grab = None;
                            }
                            KeyCode::Digit2 => {
                                scene = Scene::build(Mesh::cube(), res, "cube".into());
                                grab = None;
                            }
                            KeyCode::ArrowUp => params.stiffness = (params.stiffness + 0.05).min(1.0),
                            KeyCode::ArrowDown => params.stiffness = (params.stiffness - 0.05).max(0.05),
                            KeyCode::PageUp | KeyCode::PageDown => {
                                res = if k == KeyCode::PageUp { (res + 2).min(40) } else { res.saturating_sub(2).max(4) };
                                let name = scene.name.clone();
                                scene = Scene::from_normalized(scene.mesh.clone(), res, name);
                                grab = None;
                            }
                            _ => {}
                        }
                    }
                }
                WindowEvent::RedrawRequested => {
                    // ---- simulate (fixed 60 Hz) ----
                    let now = Instant::now();
                    acc += (now - last).as_secs_f32().min(0.1);
                    last = now;
                    let dt = 1.0 / 60.0;
                    let mut steps = 0;
                    while acc >= dt && steps < 3 {
                        let g = if left {
                            grab.map(|(i, depth)| {
                                let (o, d) = ray(mouse, &cam, &window);
                                (i, o + d * depth)
                            })
                        } else {
                            None
                        };
                        scene.body.step(dt, &params, g);
                        acc -= dt;
                        steps += 1;
                    }
                    if steps == 3 {
                        acc = 0.0;
                    }
                    scene.refresh();

                    // ---- render ----
                    let vp = cam.view_proj(renderer.aspect());
                    renderer.begin(vp.to_cols_array(), [light.x, light.y, light.z, 0.0], [0.05, 0.06, 0.08, 1.0]);
                    renderer.draw_triangles(&ground_v, &ground_i);
                    renderer.draw_lines(&grid_lines);
                    renderer.draw_triangles(&scene.verts, &scene.mesh.indices);
                    if show_springs {
                        let mut lines = Vec::with_capacity(scene.body.springs.len() * 2);
                        for s in &scene.body.springs {
                            let a = scene.body.nodes[s.a as usize].pos;
                            let b = scene.body.nodes[s.b as usize].pos;
                            let strain = (((a - b).length() - s.rest) / s.rest).abs();
                            let t = (strain * 6.0).min(1.0);
                            let col = [t, 1.0 - t * 0.7, 0.3];
                            lines.push(Vertex { pos: a.to_array(), nrm: [0.0; 3], col });
                            lines.push(Vertex { pos: b.to_array(), nrm: [0.0; 3], col });
                        }
                        renderer.draw_lines(&lines);
                    }
                    renderer.end();

                    frames += 1;
                    if frames % 30 == 0 {
                        window.set_title(&format!(
                            "SoftForge | nodes {} springs {} | res {} | stiffness {:.2} | {}",
                            scene.body.nodes.len(),
                            scene.body.springs.len(),
                            res,
                            params.stiffness,
                            scene.name
                        ));
                    }
                }
                _ => {}
            },
            _ => {}
        })
        .expect("event loop run");
}
