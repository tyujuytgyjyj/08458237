cbuffer CB : register(b0)
{
    float4x4 vp;
    float4   light; // xyz = direction towards the light
};

struct VSIn  { float3 pos : POSITION; float3 nrm : NORMAL; float3 col : COLOR; };
struct VSOut { float4 pos : SV_POSITION; float3 nrm : NORMAL; float3 col : COLOR; };

VSOut VSMain(VSIn i)
{
    VSOut o;
    o.pos = mul(vp, float4(i.pos, 1.0));
    o.nrm = i.nrm;
    o.col = i.col;
    return o;
}

float4 PSMain(VSOut i) : SV_TARGET
{
    // zero normal = unlit (lines)
    if (dot(i.nrm, i.nrm) < 0.0001) return float4(i.col, 1.0);
    float3 n = normalize(i.nrm);
    float d = abs(dot(n, normalize(light.xyz)));      // two-sided lighting
    float hemi = 0.5 + 0.5 * n.y;
    float3 c = i.col * (0.25 + 0.2 * hemi + 0.75 * d);
    return float4(c, 1.0);
}
