#[cfg(windows)]
mod app;
#[cfg(windows)]
mod renderer;

#[cfg(windows)]
fn main() {
    app::run();
}

#[cfg(not(windows))]
fn main() {
    eprintln!("SoftForge renders with Direct3D 11 and runs on Windows only.");
}
