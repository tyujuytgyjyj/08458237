use glam::Vec3;

pub struct Node {
    pub pos: Vec3,
    pub prev: Vec3,
    pub inv_mass: f32,
}

pub struct Spring {
    pub a: u32,
    pub b: u32,
    pub rest: f32,
}

#[derive(Clone, Copy)]
pub struct Params {
    pub gravity: f32,
    pub damping: f32,    // velocity kept per substep (0.99 = light damping)
    pub stiffness: f32,  // 0..1 per solver iteration
    pub substeps: u32,
    pub iterations: u32,
    pub friction: f32,   // 0..1 on ground contact
    pub floor_y: f32,
    pub wall: f32,       // half-size of the arena on X/Z
}

impl Default for Params {
    fn default() -> Self {
        Params { gravity: -9.81, damping: 0.995, stiffness: 0.4, substeps: 4, iterations: 4,
                 friction: 0.35, floor_y: 0.0, wall: 8.0 }
    }
}

/// Mass-spring soft body solved with position-based dynamics (stable at high stiffness).
pub struct SoftBody {
    pub nodes: Vec<Node>,
    pub springs: Vec<Spring>,
}

impl SoftBody {
    pub fn step(&mut self, dt: f32, p: &Params, grab: Option<(usize, Vec3)>) {
        let h = dt / p.substeps as f32;
        for _ in 0..p.substeps {
            for n in &mut self.nodes {
                if n.inv_mass == 0.0 { continue; }
                let vel = (n.pos - n.prev) * p.damping;
                n.prev = n.pos;
                n.pos += vel + Vec3::new(0.0, p.gravity * h * h, 0.0);
            }
            if let Some((i, target)) = grab {
                let n = &mut self.nodes[i];
                let d = target - n.pos;
                n.pos += d.clamp_length_max(1.0) * 0.35;
            }
            for _ in 0..p.iterations {
                for s in &self.springs {
                    let (a, b) = (s.a as usize, s.b as usize);
                    let delta = self.nodes[b].pos - self.nodes[a].pos;
                    let d = delta.length();
                    if d < 1e-7 { continue; }
                    let (wa, wb) = (self.nodes[a].inv_mass, self.nodes[b].inv_mass);
                    let w = wa + wb;
                    if w == 0.0 { continue; }
                    let corr = delta * ((d - s.rest) / d / w * p.stiffness);
                    self.nodes[a].pos += corr * wa;
                    self.nodes[b].pos -= corr * wb;
                }
                self.collide(p);
            }
        }
    }

    fn collide(&mut self, p: &Params) {
        for n in &mut self.nodes {
            if n.pos.y < p.floor_y {
                n.pos.y = p.floor_y;
                // friction: drag horizontal motion back toward previous position
                n.pos.x += (n.prev.x - n.pos.x) * p.friction;
                n.pos.z += (n.prev.z - n.pos.z) * p.friction;
            }
            n.pos.x = n.pos.x.clamp(-p.wall, p.wall);
            n.pos.z = n.pos.z.clamp(-p.wall, p.wall);
        }
    }

    /// Node closest to a ray: returns (index, distance along ray, distance from ray).
    pub fn pick(&self, origin: Vec3, dir: Vec3) -> Option<(usize, f32, f32)> {
        let mut best: Option<(usize, f32, f32)> = None;
        for (i, n) in self.nodes.iter().enumerate() {
            let t = (n.pos - origin).dot(dir);
            if t <= 0.0 { continue; }
            let d = (n.pos - (origin + dir * t)).length();
            if best.map_or(true, |b| d < b.2) { best = Some((i, t, d)); }
        }
        best
    }

    pub fn max_strain(&self) -> f32 {
        self.springs.iter().map(|s| {
            let d = (self.nodes[s.b as usize].pos - self.nodes[s.a as usize].pos).length();
            ((d - s.rest) / s.rest).abs()
        }).fold(0.0, f32::max)
    }
}
