//! SoftForge core: mesh import -> voxel lattice -> soft body + skinning.
pub mod mesh;
pub mod softbody;
pub mod voxelize;
